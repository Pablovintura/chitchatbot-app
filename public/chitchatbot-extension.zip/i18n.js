// Menu text in a few languages. Picks the browser language unless the user chose one in Support.
(function () {
  var D = {
    en: { settings:'Settings', tagSub:'Shows which language it came from', reading:'Reading', writing:'Writing', emotes:'Emotes', support:'Support',
      into:'Translate chat into', both:'Show both', only:'Translation only',
      tag:'Language tag', autoDl:'Auto-download languages', autoDlSub:'Starts on your next click. Browsers are picky.',
      replies:'Translate replies', repliesSub:'The quoted line above a reply. Yep.',
      sendIn:'Send in', auto:'Auto (chat language)', preview:'Preview before sending', previewSub:'Check it before you embarrass yourself',
      enter:'Enter sends', trans:'Translation', orig:'Original', enterHint:'Shift+Enter sends the other one. Choose wisely.',
      incEmo:'Include emotes', incEmoSub:'Your KEKW survives the trip',
      third:'7TV, BTTV and FFZ emotes', thirdSub:'They stay put in translations and your preview. Needs the 7TV extension.',
      hey:'Oh, you scrolled all the way here 👀', heyBody:'Free. No ads, no tracking, no secret paywall. If it saved you from nodding at a roast, pay what you like. Or don’t. We’ll cry quietly.',
      pay:'♥ Fine, take my money', payHint:'Opens Stripe in a new tab. Very official.', bug:'Report a bug', bugHint:'Something broke? Tell us. We’ll act surprised.',
      menuLang:'Menu language', menuAuto:'Auto (browser)', warn:'This needs Chrome 138 or newer on a desktop computer.',
      foot:'Only you see it. Chat has no clue.', on:'Translating chat for you', off:'Paused. Chat is on its own.' },
    es: { settings:'Ajustes', tagSub:'Muestra de qué idioma viene', reading:'Lectura', writing:'Escritura', emotes:'Emotes', support:'Apoyo',
      into:'Traducir el chat a', both:'Mostrar ambos', only:'Solo traducción',
      tag:'Etiqueta de idioma', autoDl:'Descargar idiomas solos', autoDlSub:'Empieza con tu próximo clic. Los navegadores son quisquillosos.',
      replies:'Traducir respuestas', repliesSub:'La línea citada sobre una respuesta. Sip.',
      sendIn:'Enviar en', auto:'Auto (idioma del chat)', preview:'Vista previa antes de enviar', previewSub:'Revísalo antes de hacer el ridículo',
      enter:'Enter envía', trans:'Traducción', orig:'Original', enterHint:'Shift+Enter envía la otra. Elige con cuidado.',
      incEmo:'Incluir emotes', incEmoSub:'Tu KEKW sobrevive al viaje',
      third:'Emotes de 7TV, BTTV y FFZ', thirdSub:'Se mantienen en las traducciones y en tu vista previa. Requiere la extensión 7TV.',
      hey:'Mira quién llegó hasta aquí 👀', heyBody:'Gratis. Sin anuncios, sin rastreo, sin muro de pago secreto. Si te salvó de asentir ante un insulto, paga lo que quieras. O no. Lloraremos en silencio.',
      pay:'♥ Vale, toma mi dinero', payHint:'Abre Stripe en una pestaña nueva. Muy oficial.', bug:'Reportar un error', bugHint:'¿Se rompió algo? Cuéntanos. Haremos como que nos sorprende.',
      menuLang:'Idioma del menú', menuAuto:'Auto (navegador)', warn:'Requiere Chrome 138 o más reciente en un ordenador.',
      foot:'Solo tú lo ves. El chat ni se entera.', on:'Traduciendo el chat para ti', off:'En pausa. El chat se las arregla solo.' },
    pt: { settings:'Ajustes', tagSub:'Mostra de qual idioma veio', reading:'Leitura', writing:'Escrita', emotes:'Emotes', support:'Apoio',
      into:'Traduzir o chat para', both:'Mostrar ambos', only:'Só tradução',
      tag:'Etiqueta de idioma', autoDl:'Baixar idiomas sozinho', autoDlSub:'Começa no seu próximo clique. Navegadores são chatos.',
      replies:'Traduzir respostas', repliesSub:'A linha citada acima de uma resposta. Pois é.',
      sendIn:'Enviar em', auto:'Auto (idioma do chat)', preview:'Prévia antes de enviar', previewSub:'Confira antes de passar vergonha',
      enter:'Enter envia', trans:'Tradução', orig:'Original', enterHint:'Shift+Enter envia a outra. Escolha bem.',
      incEmo:'Incluir emotes', incEmoSub:'Seu KEKW sobrevive à viagem',
      third:'Emotes 7TV, BTTV e FFZ', thirdSub:'Ficam nas traduções e na sua prévia. Precisa da extensão 7TV.',
      hey:'Olha quem chegou até aqui 👀', heyBody:'Grátis. Sem anúncios, sem rastreamento, sem paywall secreto. Se ele te salvou de concordar com um xingamento, pague o quanto quiser. Ou não. Vamos chorar baixinho.',
      pay:'♥ Tá bom, toma meu dinheiro', payHint:'Abre o Stripe em uma nova aba. Bem oficial.', bug:'Reportar um erro', bugHint:'Algo quebrou? Conta pra gente. Vamos fingir surpresa.',
      menuLang:'Idioma do menu', menuAuto:'Auto (navegador)', warn:'Requer Chrome 138 ou mais novo em um computador.',
      foot:'Só você vê. O chat não faz ideia.', on:'Traduzindo o chat para você', off:'Pausado. O chat que se vire.' },
    fr: { settings:'Réglages', tagSub:'Indique de quelle langue ça vient', reading:'Lecture', writing:'Écriture', emotes:'Emotes', support:'Soutien',
      into:'Traduire le chat en', both:'Afficher les deux', only:'Traduction seule',
      tag:'Étiquette de langue', autoDl:'Télécharger les langues seul', autoDlSub:'Démarre à ton prochain clic. Les navigateurs sont pointilleux.',
      replies:'Traduire les réponses', repliesSub:'La ligne citée au-dessus d’une réponse. Ouais.',
      sendIn:'Envoyer en', auto:'Auto (langue du chat)', preview:'Aperçu avant l’envoi', previewSub:'Vérifie avant de te ridiculiser',
      enter:'Entrée envoie', trans:'Traduction', orig:'Original', enterHint:'Maj+Entrée envoie l’autre. Choisis bien.',
      incEmo:'Inclure les emotes', incEmoSub:'Ton KEKW survit au voyage',
      third:'Emotes 7TV, BTTV et FFZ', thirdSub:'Gardées dans les traductions et l’aperçu. Nécessite l’extension 7TV.',
      hey:'Tiens, tu as scrollé jusqu’ici 👀', heyBody:'Gratuit. Pas de pub, pas de suivi, pas de paywall secret. S’il t’a évité de hocher la tête devant une vanne, paie ce que tu veux. Ou pas. On pleurera en silence.',
      pay:'♥ Bon, prenez mon argent', payHint:'Ouvre Stripe dans un nouvel onglet. Très officiel.', bug:'Signaler un bug', bugHint:'Un truc a planté ? Dis-le nous. On fera mine d’être surpris.',
      menuLang:'Langue du menu', menuAuto:'Auto (navigateur)', warn:'Nécessite Chrome 138 ou plus récent sur ordinateur.',
      foot:'Toi seul le vois. Le chat n’en sait rien.', on:'Traduction du chat en cours', off:'En pause. Le chat se débrouille.' },
    ja: { settings:'設定', tagSub:'どの言語からかを表示します', reading:'読む', writing:'書く', emotes:'エモート', support:'応援',
      into:'チャットの翻訳先', both:'両方を表示', only:'翻訳のみ',
      tag:'言語タグ', autoDl:'言語を自動ダウンロード', autoDlSub:'次のクリックで開始します。ブラウザは気難しいので。',
      replies:'返信を翻訳', repliesSub:'返信の上の引用行。そう、それも。',
      sendIn:'送信する言語', auto:'自動（チャットの言語）', preview:'送信前にプレビュー', previewSub:'恥をかく前に確認しよう',
      enter:'Enterで送信', trans:'翻訳', orig:'原文', enterHint:'Shift+Enterでもう一方を送信。慎重に選んでね。',
      incEmo:'エモートを含める', incEmoSub:'あなたのKEKWも一緒に旅をします',
      third:'7TV・BTTV・FFZのエモート', thirdSub:'翻訳とプレビューに残します。7TV拡張機能が必要です。',
      hey:'ここまでスクロールしたんだ 👀', heyBody:'無料。広告なし、追跡なし、隠れ課金なし。煽りにうなずかずに済んだなら、気持ちだけどうぞ。払わなくてもいいよ。静かに泣くけど。',
      pay:'♥ しょうがない、払うよ', payHint:'新しいタブでStripeを開きます。かなり公式。', bug:'不具合を報告', bugHint:'壊れた？教えてね。驚いたふりをします。',
      menuLang:'メニューの言語', menuAuto:'自動（ブラウザ）', warn:'デスクトップのChrome 138以降が必要です。',
      foot:'見えるのはあなただけ。チャットは気づかない。', on:'チャットを翻訳中', off:'一時停止中。チャットは自力で頑張ってね。' },
    ko: { settings:'설정', tagSub:'어떤 언어에서 왔는지 보여줘요', reading:'읽기', writing:'쓰기', emotes:'이모트', support:'후원',
      into:'채팅 번역 언어', both:'둘 다 표시', only:'번역만',
      tag:'언어 태그', autoDl:'언어 자동 다운로드', autoDlSub:'다음 클릭 때 시작돼요. 브라우저가 까다로워서요.',
      replies:'답장 번역', repliesSub:'답장 위의 인용 줄. 네, 그것도요.',
      sendIn:'보낼 언어', auto:'자동 (채팅 언어)', preview:'보내기 전 미리보기', previewSub:'망신당하기 전에 확인하세요',
      enter:'Enter로 보내기', trans:'번역', orig:'원문', enterHint:'Shift+Enter는 다른 쪽을 보내요. 신중하게 고르세요.',
      incEmo:'이모트 포함', incEmoSub:'당신의 KEKW도 무사히 건너가요',
      third:'7TV, BTTV, FFZ 이모트', thirdSub:'번역과 미리보기에 유지돼요. 7TV 확장 프로그램이 필요해요.',
      hey:'여기까지 스크롤했네요 👀', heyBody:'무료예요. 광고도, 추적도, 숨은 유료 벽도 없어요. 놀림에 고개만 끄덕이는 걸 막아줬다면, 원하는 만큼 후원하세요. 안 해도 돼요. 조용히 울게요.',
      pay:'♥ 알겠어요, 내 돈 가져가요', payHint:'새 탭에서 Stripe가 열려요. 엄청 공식적이에요.', bug:'버그 신고', bugHint:'뭔가 고장 났나요? 알려주세요. 놀란 척할게요.',
      menuLang:'메뉴 언어', menuAuto:'자동 (브라우저)', warn:'데스크톱 Chrome 138 이상이 필요해요.',
      foot:'나만 보여요. 채팅은 몰라요.', on:'채팅을 번역하는 중', off:'일시정지. 채팅은 알아서 하겠죠.' }
  };
  var NAMES = { en:'English', es:'Español', pt:'Português', fr:'Français', ja:'日本語', ko:'한국어' };
  var cur = 'en';
  function pick(pref) {
    if (pref && D[pref]) return pref;
    var b = (navigator.language || 'en').split('-')[0].toLowerCase();
    return D[b] ? b : 'en';
  }
  window.CBI = {
    names: NAMES,
    t: function (k) { return (D[cur] && D[cur][k]) || D.en[k] || k; },
    set: function (pref) {
      cur = pick(pref);
      document.documentElement.lang = cur;
      document.querySelectorAll('[data-i18n]').forEach(function (el) { el.textContent = window.CBI.t(el.getAttribute('data-i18n')); });
    }
  };
})();
