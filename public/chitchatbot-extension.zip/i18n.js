// Menu text in a few languages. Picks the browser language unless the user chose one in Support.
(function () {
  var D = {
    en: { reading:'Reading', writing:'Writing', emotes:'Emotes', support:'Support',
      into:'Translate chat into', both:'Show both', only:'Translation only',
      tag:'Language tag', autoDl:'Auto-download languages', autoDlSub:'Starts on your next click',
      replies:'Translate replies', repliesSub:'The quoted line above a reply',
      sendIn:'Send in', auto:'Auto (chat language)', preview:'Preview before sending', previewSub:'Shows above the chat box',
      enter:'Enter sends', trans:'Translation', orig:'Original', enterHint:'Shift+Enter sends the other one.',
      incEmo:'Include emotes', incEmoSub:'Keep emotes in the translated line',
      third:'7TV, BTTV and FFZ emotes', thirdSub:'Keep them in translations and your preview. Needs the 7TV extension.',
      hey:'Hey chatter 👋', heyBody:'ChitChatBot is free, with no ads and no tracking, and it stays that way. If it helps your chat, you can pay what you like to keep it going. Totally optional.',
      pay:'♥ Pay what you like', payHint:'Opens a secure Stripe page in a new tab.', bug:'Report a bug', bugHint:'Opens a short form in a new tab.',
      menuLang:'Menu language', menuAuto:'Auto (browser)', warn:'This needs Chrome 138 or newer on a desktop computer.',
      foot:'Only your view changes', on:'Translating chat for you', off:'Paused' },
    es: { reading:'Lectura', writing:'Escritura', emotes:'Emotes', support:'Apoyo',
      into:'Traducir el chat a', both:'Mostrar ambos', only:'Solo traducción',
      tag:'Etiqueta de idioma', autoDl:'Descargar idiomas solos', autoDlSub:'Empieza con tu próximo clic',
      replies:'Traducir respuestas', repliesSub:'La línea citada sobre una respuesta',
      sendIn:'Enviar en', auto:'Auto (idioma del chat)', preview:'Vista previa antes de enviar', previewSub:'Aparece sobre la caja del chat',
      enter:'Enter envía', trans:'Traducción', orig:'Original', enterHint:'Shift+Enter envía la otra.',
      incEmo:'Incluir emotes', incEmoSub:'Mantiene los emotes en la línea traducida',
      third:'Emotes de 7TV, BTTV y FFZ', thirdSub:'Se mantienen en las traducciones y en tu vista previa. Requiere la extensión 7TV.',
      hey:'Hola, chatter 👋', heyBody:'ChitChatBot es gratis, sin anuncios ni rastreo, y seguirá así. Si le sirve a tu chat, puedes pagar lo que quieras para mantenerlo. Totalmente opcional.',
      pay:'♥ Paga lo que quieras', payHint:'Abre una página segura de Stripe en una pestaña nueva.', bug:'Reportar un error', bugHint:'Abre un formulario corto en una pestaña nueva.',
      menuLang:'Idioma del menú', menuAuto:'Auto (navegador)', warn:'Requiere Chrome 138 o más reciente en un ordenador.',
      foot:'Solo cambia tu vista', on:'Traduciendo el chat para ti', off:'En pausa' },
    pt: { reading:'Leitura', writing:'Escrita', emotes:'Emotes', support:'Apoio',
      into:'Traduzir o chat para', both:'Mostrar ambos', only:'Só tradução',
      tag:'Etiqueta de idioma', autoDl:'Baixar idiomas sozinho', autoDlSub:'Começa no seu próximo clique',
      replies:'Traduzir respostas', repliesSub:'A linha citada acima de uma resposta',
      sendIn:'Enviar em', auto:'Auto (idioma do chat)', preview:'Prévia antes de enviar', previewSub:'Aparece acima da caixa do chat',
      enter:'Enter envia', trans:'Tradução', orig:'Original', enterHint:'Shift+Enter envia a outra.',
      incEmo:'Incluir emotes', incEmoSub:'Mantém os emotes na linha traduzida',
      third:'Emotes 7TV, BTTV e FFZ', thirdSub:'Ficam nas traduções e na sua prévia. Precisa da extensão 7TV.',
      hey:'Oi, chatter 👋', heyBody:'O ChitChatBot é grátis, sem anúncios nem rastreamento, e vai continuar assim. Se ajuda seu chat, pague o quanto quiser para mantê-lo. Totalmente opcional.',
      pay:'♥ Pague o quanto quiser', payHint:'Abre uma página segura do Stripe em uma nova aba.', bug:'Reportar um erro', bugHint:'Abre um formulário curto em uma nova aba.',
      menuLang:'Idioma do menu', menuAuto:'Auto (navegador)', warn:'Requer Chrome 138 ou mais novo em um computador.',
      foot:'Só a sua visão muda', on:'Traduzindo o chat para você', off:'Pausado' },
    fr: { reading:'Lecture', writing:'Écriture', emotes:'Emotes', support:'Soutien',
      into:'Traduire le chat en', both:'Afficher les deux', only:'Traduction seule',
      tag:'Étiquette de langue', autoDl:'Télécharger les langues seul', autoDlSub:'Démarre à votre prochain clic',
      replies:'Traduire les réponses', repliesSub:'La ligne citée au-dessus d’une réponse',
      sendIn:'Envoyer en', auto:'Auto (langue du chat)', preview:'Aperçu avant l’envoi', previewSub:'S’affiche au-dessus de la zone de chat',
      enter:'Entrée envoie', trans:'Traduction', orig:'Original', enterHint:'Maj+Entrée envoie l’autre.',
      incEmo:'Inclure les emotes', incEmoSub:'Garde les emotes dans la ligne traduite',
      third:'Emotes 7TV, BTTV et FFZ', thirdSub:'Gardées dans les traductions et l’aperçu. Nécessite l’extension 7TV.',
      hey:'Salut, chatter 👋', heyBody:'ChitChatBot est gratuit, sans pub ni suivi, et ça ne changera pas. Si ça aide votre chat, payez ce que vous voulez pour le faire vivre. Totalement facultatif.',
      pay:'♥ Payez ce que vous voulez', payHint:'Ouvre une page Stripe sécurisée dans un nouvel onglet.', bug:'Signaler un bug', bugHint:'Ouvre un court formulaire dans un nouvel onglet.',
      menuLang:'Langue du menu', menuAuto:'Auto (navigateur)', warn:'Nécessite Chrome 138 ou plus récent sur ordinateur.',
      foot:'Seul votre affichage change', on:'Traduction du chat en cours', off:'En pause' },
    ja: { reading:'読む', writing:'書く', emotes:'エモート', support:'応援',
      into:'チャットの翻訳先', both:'両方を表示', only:'翻訳のみ',
      tag:'言語タグ', autoDl:'言語を自動ダウンロード', autoDlSub:'次のクリックで開始します',
      replies:'返信を翻訳', repliesSub:'返信の上の引用行',
      sendIn:'送信する言語', auto:'自動（チャットの言語）', preview:'送信前にプレビュー', previewSub:'チャット欄の上に表示されます',
      enter:'Enterで送信', trans:'翻訳', orig:'原文', enterHint:'Shift+Enterでもう一方を送信します。',
      incEmo:'エモートを含める', incEmoSub:'翻訳した行にもエモートを残します',
      third:'7TV・BTTV・FFZのエモート', thirdSub:'翻訳とプレビューに残します。7TV拡張機能が必要です。',
      hey:'やあ、チャッター 👋', heyBody:'ChitChatBotは無料で、広告も追跡もなく、これからも変わりません。チャットの役に立ったら、気持ちだけ支援してもらえると続けられます。完全に任意です。',
      pay:'♥ 好きな金額で応援', payHint:'新しいタブでStripeの安全なページを開きます。', bug:'不具合を報告', bugHint:'新しいタブで短いフォームを開きます。',
      menuLang:'メニューの言語', menuAuto:'自動（ブラウザ）', warn:'デスクトップのChrome 138以降が必要です。',
      foot:'変わるのはあなたの表示だけ', on:'チャットを翻訳中', off:'一時停止中' },
    ko: { reading:'읽기', writing:'쓰기', emotes:'이모트', support:'후원',
      into:'채팅 번역 언어', both:'둘 다 표시', only:'번역만',
      tag:'언어 태그', autoDl:'언어 자동 다운로드', autoDlSub:'다음 클릭 때 시작돼요',
      replies:'답장 번역', repliesSub:'답장 위의 인용 줄',
      sendIn:'보낼 언어', auto:'자동 (채팅 언어)', preview:'보내기 전 미리보기', previewSub:'채팅 입력창 위에 표시돼요',
      enter:'Enter로 보내기', trans:'번역', orig:'원문', enterHint:'Shift+Enter는 다른 쪽을 보내요.',
      incEmo:'이모트 포함', incEmoSub:'번역된 줄에도 이모트를 유지해요',
      third:'7TV, BTTV, FFZ 이모트', thirdSub:'번역과 미리보기에 유지돼요. 7TV 확장 프로그램이 필요해요.',
      hey:'안녕하세요, 채터님 👋', heyBody:'ChitChatBot은 무료이고 광고도 추적도 없으며, 앞으로도 그래요. 채팅에 도움이 됐다면 원하는 만큼 후원해 주세요. 완전히 자유예요.',
      pay:'♥ 원하는 만큼 후원', payHint:'새 탭에서 안전한 Stripe 페이지가 열려요.', bug:'버그 신고', bugHint:'새 탭에서 짧은 양식이 열려요.',
      menuLang:'메뉴 언어', menuAuto:'자동 (브라우저)', warn:'데스크톱 Chrome 138 이상이 필요해요.',
      foot:'내 화면만 바뀌어요', on:'채팅을 번역하는 중', off:'일시정지' }
  };
  var NAMES = { en:'English', es:'Español', pt:'Português', fr:'Français', ja:'日本語', ko:'한국어' };
  var cur = 'en';
  function pick(pref) {
    if (pref && D[pref]) return pref;
    var b = (navigator.language || 'en').split('-')[0].toLowerCase();
    return D[b] ? b : 'en';
  }
  window.CBI = {
    names: NAMES,
    t: function (k) { return (D[cur] && D[cur][k]) || D.en[k] || k; },
    set: function (pref) {
      cur = pick(pref);
      document.documentElement.lang = cur;
      document.querySelectorAll('[data-i18n]').forEach(function (el) { el.textContent = window.CBI.t(el.getAttribute('data-i18n')); });
    }
  };
})();
