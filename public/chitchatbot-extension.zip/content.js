// ChitChatBot content script: translates live chat messages in place (Kick, Twitch, YouTube).
(function () {
  'use strict';
  if (window.__chitchatbot) return;
  window.__chitchatbot = true;

  var DEFAULTS = {
    enabled: true,
    target: (navigator.language || 'en').split('-')[0].toLowerCase(),
    showOriginal: true,
    showEmotes: true,
    showReplies: true,
    write: true, showTag: false,
    writeTo: 'auto',
    writeAsk: true,
    enterTr: true,
    enterOwn: false,
    autoPack: true,
    thirdParty: true,
    skip: []
  };

  // ---- the three supported sites ----
  // Each site describes where its chat lives and how a message is built.
  function findChatButton(ed) {
    var el = ed;
    for (var i = 0; i < 8 && el && el.parentElement; i++) {
      el = el.parentElement;
      var btns = el.querySelectorAll('button');
      for (var j = 0; j < btns.length; j++) {
        if (btns[j].textContent.trim() === 'Chat' && !btns[j].disabled) return btns[j];
      }
    }
    return null;
  }
  var SITES = {
    kick: {
      id: 'kick', rgb: '83,252,24', solid: '#53fc18', ink: '#0a1a03',
      room: function () { return document.querySelector('#chatroom-messages'); },
      scroller: function (room) { return room; },
      items: function (room) { return room.querySelectorAll('[data-index]'); },
      user: function (item) { var b = item.querySelector('button[data-prevent-expand][title]'); return b ? (b.getAttribute('title') || b.textContent) : ''; },
      textNodes: function (item) { return item.querySelectorAll('span.font-normal'); },
      isEmote: function (n) { return n.nodeType === 1 && n.hasAttribute('data-emote-id'); },
      emoteId: function (n) { return n.getAttribute('data-emote-id'); },
      anchor: function (item) {
        var s = item.querySelector('span.font-normal');
        return s && (s.closest('.break-words') || s.parentElement);
      },
      reply: function (item) {
        var s = item.querySelector('button span.ml-1 > span.inline');
        return s ? { span: s, after: s.closest('button') } : null;
      },
      input: '[data-testid="chat-input"]',
      box: function (ed) { return document.getElementById('chat-input-wrapper') || ed; },
      send: findChatButton
    },
    twitch: {
      id: 'twitch', rgb: '145,70,255', solid: '#9146ff', ink: '#ffffff',
      room: function () { return document.querySelector('.chat-scrollable-area__message-container'); },
      scroller: function (room) { return room.closest('.scrollable-area') || room.parentElement; },
      items: function (room) { return room.querySelectorAll('.chat-line__message'); },
      user: function (item) { var u = item.querySelector('[data-a-user]'); return u ? (u.getAttribute('data-a-user') || u.textContent) : ''; },
      textNodes: function (item) { return item.querySelectorAll('[data-a-target="chat-line-message-body"]'); },
      isEmote: function (n) {
        return n.nodeType === 1 && (n.matches('.chat-line__message--emote-button') || !!n.querySelector('img.chat-image'));
      },
      emoteId: function (n) { var i = n.querySelector('img'); return i ? (i.getAttribute('src') || i.alt) : ''; },
      anchor: function (item) { return item.querySelector('.chat-line__message-container'); },
      reply: function (item) {
        var p = item.querySelector('.chat-line__message-container p[title]');
        if (!p) return null;
        var spans = p.querySelectorAll('span[dir="auto"]');
        if (spans.length < 2) return null;
        var box = p.parentElement && p.parentElement.parentElement;
        return box ? { span: spans[spans.length - 1], after: box } : null;
      },
      input: '[data-a-target="chat-input"]',
      // The framed input (with its icons), found by climbing until the Chat button row would be included.
      box: function (ed) {
        var el = ed, btn = document.querySelector('[data-a-target="chat-send-button"]');
        for (var i = 0; i < 8 && el.parentElement; i++) {
          var up = el.parentElement;
          if ((btn && up.contains(btn)) || up.getBoundingClientRect().height > 140) break;
          el = up;
        }
        return el;
      },
      send: function () {
        var b = document.querySelector('[data-a-target="chat-send-button"]');
        return b && !b.disabled ? b : null;
      }
    },
    tiktok: {
      id: 'tiktok', rgb: '254,44,85', solid: '#fe2c55', ink: '#ffffff',
      room: function () { return document.querySelector('[data-e2e="live-chat-container"]'); },
      scroller: function (room) {
        var m = room.querySelector('[data-e2e="chat-message"]'), e = m;
        while (e && e !== room) { if (/auto|scroll/.test(getComputedStyle(e).overflowY)) return e; e = e.parentElement; }
        return room.querySelector('.overflow-y-scroll') || room;
      },
      items: function (room) { return room.querySelectorAll('[data-e2e="chat-message"]'); },
      user: function (item) { var u = item.querySelector('[data-e2e="message-owner-name"]'); return u ? u.textContent : ''; },
      // The message text is the line under the row with the username.
      textNodes: function (item) {
        var o = item.querySelector('[data-e2e="message-owner-name"]');
        var row = o && o.closest('.w-full');
        while (row && row.parentElement !== item && row.nextElementSibling === null && row.parentElement) row = row.parentElement;
        var t = row && row.nextElementSibling;
        return t ? [t] : [];
      },
      isEmote: function (n) { return n.nodeType === 1 && n.tagName === 'IMG'; },
      emoteId: function (n) { return n.getAttribute('src') || n.getAttribute('alt') || ''; },
      anchor: function (item) {
        var t = this.textNodes(item)[0];
        return t && t.parentElement;
      },
      reply: function () { return null; },
      pickerBtn: '[data-e2e="room-chat-emoji-btn"]',
      input: '[data-e2e="room-chat-input-field"]',
      box: function (ed) { return ed.closest('[data-e2e="live-chat-input-container"]') || ed.parentElement || ed; },
      send: function () {
        var b = document.querySelector('[data-e2e="room-chat-send-btn"]');
        return b && !/cursor-not-allowed|invisible/.test(b.className) ? b : null;
      }
    },
    youtube: {
      id: 'youtube', rgb: '255,64,64', solid: '#ff3b30', ink: '#ffffff',
      room: function () { return document.querySelector('yt-live-chat-item-list-renderer #items'); },
      scroller: function (room) { return document.querySelector('#item-scroller') || room; },
      items: function (room) { return room.querySelectorAll('yt-live-chat-text-message-renderer'); },
      user: function (item) { var u = item.querySelector('#author-name'); return u ? u.textContent : ''; },
      textNodes: function (item) { return item.querySelectorAll('#message'); },
      isEmote: function (n) { return n.nodeType === 1 && n.tagName === 'IMG'; },
      emoteId: function (n) { return n.getAttribute('data-emoji-id') || n.getAttribute('src') || n.getAttribute('alt') || ''; },
      anchor: function (item) { return item.querySelector('#content'); },
      reply: function () { return null; },
      input: 'yt-live-chat-text-input-field-renderer #input',
      box: function (ed) { return ed.closest('yt-live-chat-message-input-renderer') || ed; },
      send: function () {
        var b = document.querySelector('yt-live-chat-message-input-renderer #send-button button');
        return b && !b.disabled ? b : null;
      }
    }
  };
  var HOST = location.hostname;
  var P = /(^|\.)kick\.com$/.test(HOST) ? SITES.kick
    : /(^|\.)twitch\.tv$/.test(HOST) ? SITES.twitch
    : /(^|\.)tiktok\.com$/.test(HOST) ? SITES.tiktok
    : /(^|\.)youtube\.com$/.test(HOST) ? SITES.youtube : null;
  if (!P) return;
  document.documentElement.dataset.cbSite = P.id;
  document.documentElement.style.setProperty('--cb-rgb', P.rgb);
  document.documentElement.style.setProperty('--cb-solid', P.solid);
  document.documentElement.style.setProperty('--cb-ink', P.ink);

  var settings = Object.assign({}, DEFAULTS);
  var room = null;
  var scheduled = false;
  var detector = null;
  var detectorState = 'idle'; // idle | init | ready | no
  var translators = new Map(); // "src>tgt" -> { t, state }
  var cache = new Map(); // "tgt|text" -> { src, out } or null (no translation needed)
  var inflight = new Set();
  var failed = new Map(); // message key -> failed attempts
  var pairFails = new Map(); // language pair -> failed set-up attempts
  var pending = new Map(); // downloads waiting for a click

  var names = null;
  try { names = new Intl.DisplayNames(['en'], { type: 'language' }); } catch (e) { /* ignore */ }
  function langName(code) {
    try { return (names && names.of(code)) || code; } catch (e) { return code; }
  }
  function base(code) { return String(code || '').split('-')[0].toLowerCase(); }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(scan);
  }

  function remember(key, val) {
    cache.set(key, val);
    if (cache.size > 800) cache.delete(cache.keys().next().value);
  }

  // ---- download prompt (needs one click from the viewer) ----
  var pillTimer = null;

  // The bar sits just above the message box (and above the translation preview when that shows).
  // With no message box on screen it falls back to the top of the chat.
  function placePill() {
    var pill = document.getElementById('cb-pill');
    if (!pill) return;
    var ed = document.querySelector(P.input);
    var box = ed && P.box(ed);
    var r = box ? box.getBoundingClientRect() : null;
    if (r && r.width > 0 && r.height > 0) {
      var wr = document.getElementById('cb-wr');
      var lift = wr && wr.style.display === 'block' ? wr.offsetHeight + 6 : 0;
      pill.style.bottom = Math.max(8, window.innerHeight - r.top + 6 + lift) + 'px';
      pill.style.left = r.left + 'px';
      pill.style.width = Math.max(180, r.width) + 'px';
      pill.style.top = 'auto';
      pill.style.right = 'auto';
      return;
    }
    var q = room && room.isConnected ? room.getBoundingClientRect() : null;
    if (q && q.width > 0 && q.height > 0) {
      pill.style.top = Math.max(8, q.top + 8) + 'px';
      pill.style.left = (q.left + 8) + 'px';
      pill.style.width = Math.max(120, q.width - 16) + 'px';
      pill.style.right = 'auto';
      pill.style.bottom = 'auto';
    }
  }

  function renderPill() {
    var pill = document.getElementById('cb-pill');
    if (!pending.size || !settings.enabled) {
      if (pill) pill.remove();
      if (pillTimer) { clearInterval(pillTimer); pillTimer = null; }
      return;
    }
    if (!pill) {
      pill = document.createElement('button');
      pill.id = 'cb-pill';
      pill.type = 'button';
      pill.addEventListener('click', onPill);
      document.body.appendChild(pill);
    }
    if (!pillTimer) pillTimer = setInterval(placePill, 500);
    placePill();
    var first = pending.values().next().value;
    if (!dlRunning) {
      pill.textContent = settings.autoPack
        ? 'ChitChatBot: getting ' + first.label + ' ready. It starts on your next click or key press.' + (pending.size > 1 ? ' +' + (pending.size - 1) + ' more' : '')
        : 'ChitChatBot: click to download ' + first.label + ' (one time)' + (pending.size > 1 ? ' +' + (pending.size - 1) + ' more' : '');
    }
  }

  function addPending(key, label, run) {
    if (pending.has(key)) return;
    pending.set(key, { label: label, run: run });
    renderPill();
  }

  var dlRunning = false;

  // With "Auto-download languages" on, the next click or key press anywhere on the page starts the download.
  // The browser only allows a download to start from a real click or key press, so it can't begin on its own.
  ['pointerdown', 'keydown'].forEach(function (ev) {
    document.addEventListener(ev, function () {
      if (settings.autoPack && settings.enabled && pending.size && !dlRunning) onPill();
    }, true);
  });

  function onPill() {
    var pill = document.getElementById('cb-pill');
    var entry = pending.entries().next().value;
    if (!entry || !pill || dlRunning) return;
    dlRunning = true;
    var key = entry[0], p = entry[1];
    pill.disabled = true;
    pill.textContent = 'Downloading ' + p.label + '...';
    p.run(function (monitor) {
      monitor.addEventListener('downloadprogress', function (e) {
        pill.textContent = 'Downloading ' + p.label + '... ' + Math.round(e.loaded * 100) + '%';
      });
    }).then(function () {
      dlRunning = false;
      pending.delete(key);
      pill.disabled = false;
      renderPill();
      schedule();
    }).catch(function () {
      dlRunning = false;
      pill.disabled = false;
      pill.textContent = 'Download failed. Click to try again: ' + p.label;
    });
  }

  // ---- language detection and translation ----
  function getDetector() {
    if (detector) return detector;
    if (detectorState !== 'idle') return null;
    if (!('LanguageDetector' in self)) { detectorState = 'no'; return null; }
    detectorState = 'init';
    LanguageDetector.availability().then(function (a) {
      if (a === 'unavailable') { detectorState = 'no'; schedule(); return; }
      if (a === 'available') {
        return LanguageDetector.create().then(function (d) {
          detector = d; detectorState = 'ready'; schedule();
        });
      }
      addPending('detector', 'the language detector', function (setup) {
        return LanguageDetector.create({ monitor: setup }).then(function (d) {
          detector = d; detectorState = 'ready';
        });
      });
    }).catch(function () {
      detectorState = 'no';
    });
    return null;
  }

  function getTranslator(src, tgt) {
    var key = src + '>' + tgt;
    var e = translators.get(key);
    if (e) return e.t;
    e = { t: null, state: 'check' };
    translators.set(key, e);
    if (!('Translator' in self)) { e.state = 'no'; return null; }
    Translator.availability({ sourceLanguage: src, targetLanguage: tgt }).then(function (a) {
      if (a === 'unavailable') { e.state = 'no'; return; }
      if (a === 'available') {
        return Translator.create({ sourceLanguage: src, targetLanguage: tgt }).then(function (t) {
          e.t = t; e.state = 'ready'; schedule();
        });
      }
      e.state = 'download';
      addPending(key, langName(src) + ' to ' + langName(tgt), function (setup) {
        return Translator.create({ sourceLanguage: src, targetLanguage: tgt, monitor: setup }).then(function (t) {
          e.t = t; e.state = 'ready';
        });
      });
    }).catch(function () {
      // Allow a few rebuild attempts before giving up on this language pair.
      var n = (pairFails.get(key) || 0) + 1;
      pairFails.set(key, n);
      if (n >= 3) e.state = 'no'; else { translators.delete(key); setTimeout(schedule, 400); }
    });
    return null;
  }

  // srcHint: the language is already known (used for the pieces of a message split around emotes).
  async function translate(text, key, srcHint) {
    var d = srcHint ? null : getDetector();
    // Some browsers (Brave, for example) block the built-in detector, so use our own guesser there.
    var fallback = !srcHint && !d && (detectorState === 'no' || pending.has('detector'));
    if (!srcHint && !d && !fallback) return; // still checking what the browser supports
    inflight.add(key);
    var deferred = false;
    var pairKey = null;
    try {
      var src;
      if (srcHint) {
        src = srcHint;
        if (base(src) === base(settings.target)) { remember(key, null); return; }
      } else {
        var top = null;
        if (d) {
          var res = await d.detect(text);
          var r0 = res && res[0];
          if (r0) top = { lang: r0.detectedLanguage, conf: r0.confidence };
        } else if (window.__cbDetect) {
          top = window.__cbDetect(text);
        }
        if (window.__cbHinglish && window.__cbHinglish(text)) top = { lang: 'hi', conf: 0.8 };
        if (top && top.conf >= 0.6 && top.lang !== 'und') noteLang(top.lang);
        if (!top || top.conf < 0.6 || top.lang === 'und' || base(top.lang) === base(settings.target)) {
          remember(key, null);
          return;
        }
        src = top.lang;
      }
      pairKey = src + '>' + settings.target;
      var t = getTranslator(src, settings.target);
      if (!t) {
        var st = translators.get(pairKey);
        if (st && st.state === 'no') remember(key, null); else deferred = true;
        return;
      }
      var out = await t.translate(text);
      var same = !out || out.trim().toLowerCase() === text.toLowerCase();
      failed.delete(key);
      remember(key, same ? null : { src: src, out: out });
    } catch (err) {
      // The browser may have closed this translator (for example after switching language).
      // Drop it so it is rebuilt, and retry this message a couple of times.
      if (pairKey) translators.delete(pairKey);
      var tries = (failed.get(key) || 0) + 1;
      failed.set(key, tries);
      if (tries >= 3) { failed.delete(key); remember(key, null); } else if (pairKey) { deferred = true; setTimeout(schedule, 400); }
    } finally {
      inflight.delete(key);
      if (!deferred) schedule();
    }
  }

  // ---- reading and writing the chat DOM ----
  function thirdSrc(n) {
    var im = n.tagName === 'IMG' ? n : n.querySelector && n.querySelector('img');
    return im ? (im.currentSrc || im.getAttribute('src') || '') : '';
  }

  // Break a message into text pieces and emotes, in the order they appear.
  function partsOf(item, direct) {
    var parts = [];
    var buf = '';
    function flush() {
      var s = buf.replace(/\s+/g, ' ').trim();
      if (s) parts.push({ t: 'text', s: s });
      buf = '';
    }
    // A reply's quoted line is passed in directly; a message is searched for its text parts.
    var spans = direct ? [item] : P.textNodes(item);
    spans.forEach(function (span) {
      span.childNodes.forEach(function (n) {
        if (n.nodeType === 8) return; // comment nodes
        if (P.isEmote(n)) {
          flush();
          if (settings.thirdParty === false && /7tv|betterttv|frankerfacez/i.test(thirdSrc(n))) return; // 7TV and friends are switched off
          parts.push({ t: 'emote', n: n });
        } else {
          buf += ' ' + n.textContent;
        }
      });
      flush();
    });
    return parts;
  }

  function textOf(parts) {
    return parts.filter(function (p) { return p.t === 'text'; })
      .map(function (p) { return p.s; }).join(' ');
  }

  function worthTranslating(s) {
    var letters = s.match(/\p{L}/gu);
    return !!letters && letters.length >= 2 && s.length <= 300;
  }

  function cloneEmote(n) {
    var c = n.cloneNode(true);
    c.removeAttribute('data-emote-id');
    c.removeAttribute('data-emote-name');
    c.removeAttribute('id');
    c.setAttribute('data-cb-emote', '1');
    return c;
  }

  function eligible(text) {
    if (text.length < 4 || text.length > 500) return false;
    var letters = text.match(/\p{L}/gu);
    if (!letters || letters.length < 3) return false;
    var noUrls = text.replace(/https?:\/\/\S+/g, '').trim();
    return noUrls.length >= 4;
  }

  // Language flag: same flags as the ChitChatBot bot (a language isn't a country: Portuguese shows Brazil).
  var FLAG_COUNTRY = { en: 'US', es: 'ES', pt: 'BR', fr: 'FR', de: 'DE', it: 'IT', nl: 'NL', pl: 'PL', tr: 'TR', id: 'ID', ms: 'MY', vi: 'VN',
    tl: 'PH', sv: 'SE', ro: 'RO', ru: 'RU', uk: 'UA', ar: 'SA', hi: 'IN', zh: 'CN', ja: 'JP', ko: 'KR', th: 'TH' };
  function flagFor(code) {
    var cc = FLAG_COUNTRY[base(code)];
    return cc ? String.fromCodePoint.apply(null, cc.split('').map(function (ch) { return 0x1F1E6 + ch.charCodeAt(0) - 65; })) : '\uD83C\uDF10';
  }

  function clear(item) {
    item.querySelectorAll('.cb-tr').forEach(function (n) { n.remove(); });
  }

  // pieces: the final translation line, in order: { t: 'text', s } or { t: 'emote', n }.
  function show(item, key, sig, src, pieces) {
    var box = P.anchor(item);
    if (!box) return;
    var div = document.createElement('div');
    div.className = 'cb-tr';
    div.dataset.key = key;
    div.dataset.sig = sig;
    var tag = document.createElement('span');
    tag.className = 'cb-tag';
    tag.textContent = flagFor(src);
    tag.title = base(src).toUpperCase() + ' > ' + base(settings.target).toUpperCase();
    div.appendChild(tag);
    pieces.forEach(function (p, i) {
      if (i) div.appendChild(document.createTextNode(' '));
      if (p.t === 'text') div.appendChild(document.createTextNode(p.s));
      else div.appendChild(cloneEmote(p.n));
    });
    box.appendChild(div);
    keepBottom();
  }

  // ---- the quoted line above a reply ("Replying to X: ...") ----
  function clearReply(item) {
    item.querySelectorAll('.cb-rtr').forEach(function (n) { n.remove(); });
  }

  function handleReply(item) {
    var existing = item.querySelector('.cb-rtr');
    var rp = P.reply(item);
    var span = rp && rp.span;
    if (!span || !settings.enabled || !settings.showReplies) { if (existing) clearReply(item); return; }
    var parts = partsOf(span, true);
    var text = textOf(parts);
    if (!eligible(text)) { if (existing) clearReply(item); return; }
    var key = settings.target + '|' + text;
    var emoteIds = settings.showEmotes ? parts.filter(function (p) { return p.t === 'emote'; })
      .map(function (p) { return P.emoteId(p.n); }).join(',') : '';
    var sig = key + '|' + emoteIds;
    if (existing && existing.dataset.sig === sig) return;
    if (existing) clearReply(item);

    if (!cache.has(key)) {
      if (!inflight.has(key)) translate(text, key);
      return;
    }
    var hit = cache.get(key);
    if (!hit) return;

    if (!rp.after) return;
    var div = document.createElement('div');
    div.className = 'cb-rtr';
    div.dataset.sig = sig;
    var tag = document.createElement('span');
    tag.className = 'cb-tag';
    tag.textContent = flagFor(hit.src);
    tag.title = base(hit.src).toUpperCase() + ' > ' + base(settings.target).toUpperCase();
    div.appendChild(tag);
    var placed = false;
    var pieces = [];
    parts.forEach(function (p) {
      if (p.t === 'emote') { if (settings.showEmotes) pieces.push(p); }
      else if (!placed) { pieces.push({ t: 'text', s: hit.out }); placed = true; }
    });
    pieces.forEach(function (p, i) {
      if (i) div.appendChild(document.createTextNode(' '));
      if (p.t === 'text') div.appendChild(document.createTextNode(p.s));
      else div.appendChild(cloneEmote(p.n));
    });
    rp.after.insertAdjacentElement('afterend', div);
    keepBottom();
  }

  // Skip list: names (any case, with or without _ and -) whose messages are never translated.
  function skipKey(n) { return String(n || '').toLowerCase().replace(/^@+/, '').replace(/[-_\s]/g, ''); }
  function isSkipped(item) {
    var list = settings.skip;
    if (!list || !list.length || !P.user) return false;
    var k = skipKey(P.user(item));
    return !!k && list.some(function (n) { return skipKey(n) === k; });
  }

  // The ChitChatBot bot (Kick) posts its own translation lines, which would show everything twice for someone
  // with this extension. Only lines from an account named like the bot, in the bot's format, are hidden.
  var BOT_LINE = /^(?:\p{Regional_Indicator}{2}|\uD83C\uDF10) [^\s:]+: /u;
  function setBotLine(item, hide) {
    var box = item.firstElementChild;
    if (box) box.toggleAttribute('data-cb-bot', hide);
  }
  function isBotLine(item) {
    if (P.id !== 'kick' || !P.user || !/chitchat/i.test(P.user(item))) return false;
    return BOT_LINE.test(textOf(partsOf(item)).trim());
  }

  function handle(item) {
    var existing = item.querySelector('.cb-tr');
    if (!settings.enabled) { setBotLine(item, false); if (existing) clear(item); return; }
    if (isBotLine(item)) { setBotLine(item, true); if (existing) clear(item); return; }
    setBotLine(item, false);
    if (isSkipped(item)) { if (existing) clear(item); return; }
    var parts = partsOf(item);
    var text = textOf(parts);
    if (!eligible(text)) { if (existing) clear(item); return; }
    var key = settings.target + '|' + text;

    // Emotes at the start or end keep the whole-sentence translation (best quality).
    // Emotes in the middle split the message, so each piece of text is translated in place.
    var first = -1, last = -1;
    parts.forEach(function (p, i) {
      if (p.t === 'text') { if (first < 0) first = i; last = i; }
    });
    var middle = settings.showEmotes && parts.some(function (p, i) {
      return p.t === 'emote' && i > first && i < last;
    });
    var emoteIds = settings.showEmotes ? parts.filter(function (p) { return p.t === 'emote'; })
      .map(function (p) { return P.emoteId(p.n); }).join(',') : '';
    var sig = key + '|' + emoteIds + '|' + (middle ? 'm' : 's');

    if (existing && existing.dataset.sig === sig) return;
    if (existing) clear(item);

    if (!cache.has(key)) {
      if (!inflight.has(key)) translate(text, key);
      return;
    }
    var hit = cache.get(key);
    if (!hit) return;

    var pieces = [];
    if (!middle) {
      var placed = false;
      parts.forEach(function (p) {
        if (p.t === 'emote') { if (settings.showEmotes) pieces.push(p); }
        else if (!placed) { pieces.push({ t: 'text', s: hit.out }); placed = true; }
      });
    } else {
      var ready = true;
      parts.forEach(function (p) {
        if (p.t === 'emote' || !worthTranslating(p.s)) { pieces.push(p); return; }
        var rk = settings.target + '|' + p.s;
        if (!cache.has(rk)) {
          ready = false;
          if (!inflight.has(rk)) translate(p.s, rk, hit.src);
          return;
        }
        var rh = cache.get(rk);
        pieces.push({ t: 'text', s: rh ? rh.out : p.s });
      });
      if (!ready) return;
    }
    show(item, key, sig, hit.src, pieces);
  }

  // ---- writing: translate what the viewer types into the language chat is using ----
  var CHAT_INPUT = P.input;
  var langLog = [];
  var wr = { text: '', to: '', out: null };
  var wrTimer = null, wrTries = 0, wrPlaceTimer = null;
  var bypass = false;
  var skipUntil = 0;

  function noteLang(l) {
    langLog.push(base(l));
    if (langLog.length > 40) langLog.shift();
  }
  // The language chat mostly uses. A mixed chat can swing between two close languages, so once one is picked
  // it holds until another clearly leads, otherwise the preview and the Enter key could disagree.
  var stickyLang = null;
  function chatLang() {
    var n = {}, best = null;
    langLog.forEach(function (l) { n[l] = (n[l] || 0) + 1; if (!best || n[l] > n[best]) best = l; });
    var cand = best && n[best] >= 3 ? best : null;
    if (stickyLang && (n[stickyLang] || 0) >= 2 && (!cand || cand === stickyLang || n[cand] < n[stickyLang] + 3)) return stickyLang;
    stickyLang = cand;
    return stickyLang;
  }
  // The language to send in, or null when chat already uses the viewer's own language.
  function writeLang() {
    var to = settings.writeTo === 'auto' ? chatLang() : base(settings.writeTo);
    return to && to !== base(settings.target) ? to : null;
  }
  function editorOf() { return document.querySelector(CHAT_INPUT); }
  function editorText(ed) {
    var ps = editorParts(ed);
    var raw = ps ? ps.map(function (p) { return p.t === 'text' ? p.s : ' '; }).join('') : (ed.innerText || '');
    return raw.replace(/[\u200b\ufeff]/g, '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim(); }

  // The box as an ordered list of text pieces and emotes, or null when it holds something else (a mention, say).
  var unknownItem = '';
  var EMOTE_SEL = 'img, canvas, svg, video, [data-emote-id]';
  function editorParts(ed) {
    var parts = [], ok = true;
    unknownItem = '';
    (function walk(n) {
      for (var c = n.firstChild; c && ok; c = c.nextSibling) {
        if (c.nodeType === 3) { if (c.nodeValue.replace(/[\u200b\ufeff]/g, '')) parts.push({ t: 'text', node: c, s: c.nodeValue.replace(/[\u200b\ufeff]/g, '') }); }
        else if (c.nodeType === 1) {
          if (c.matches(EMOTE_SEL)) parts.push({ t: 'emote', n: c });
          else if (c.querySelector(EMOTE_SEL)) { var e = c.matches('img') ? c : c.querySelector(EMOTE_SEL); if (c.getAttribute('contenteditable') === 'false' || c.hasAttribute('data-emote-id')) parts.push({ t: 'emote', n: c }); else walk(c); }
          else if (c.getAttribute('contenteditable') === 'false' || /seventv|7tv|emote/i.test(c.className && c.className.baseVal === undefined ? String(c.className) : '')) {
            if (/^\s*@/.test(c.textContent || '')) { ok = false; unknownItem = c.tagName.toLowerCase() + '.' + String(c.className).slice(0, 40); }
            else parts.push({ t: 'emote', n: c }); // an emote drawn some other way (7TV, say): keep it as is
          }
          else walk(c);
        }
      }
    })(ed);
    return ok ? parts : null;
  }
  function partsSig(parts) {
    return parts.map(function (p) { return p.t === 'emote' ? '<' + (p.n.getAttribute('src') || p.n.getAttribute('alt') || p.n.getAttribute('data-emote-id') || (p.n.querySelector('img') || {}).src || '') + '>' : p.s; }).join('');
  }

  // Emotes the chat is showing right now, by name. 7TV, BetterTTV and FrankerFaceZ names stay plain text in the
  // box until they are sent, so this is how they are told apart from ordinary words.
  var knownCache = { at: 0, map: null }, seenEmotes = new Map();
  var EMOTE_SRC = /7tv|betterttv|frankerfacez|emote|emoticon/i;
  function knownEmotes() {
    if (knownCache.map && Date.now() - knownCache.at < 500) return knownCache.map;
    var r = room || (P.room && P.room());
    // Emote pictures in chat and in any emote window (7TV's, say). Names stay known after they scroll away.
    document.querySelectorAll('img').forEach(function (im) {
      if (im.closest('#cb-wr')) return;
      var host = im.closest('[data-emote-name]');
      var nm = (host && host.getAttribute('data-emote-name')) || im.getAttribute('data-emote-name') || im.getAttribute('alt') || im.getAttribute('title') || '';
      if (!/^[^\s]{2,40}$/.test(nm) || /^https?:/i.test(nm)) return;
      var src = im.currentSrc || im.getAttribute('src') || '';
      if (!(r && r.contains(im)) && !EMOTE_SRC.test(src)) return;
      if (seenEmotes.size > 3000) seenEmotes.clear();
      seenEmotes.set(nm, im.cloneNode(true));
    });
    knownCache = { at: Date.now(), map: seenEmotes };
    return seenEmotes;
  }
  // 7TV's global emotes work in every channel, so their names are always kept as typed, even before the chat shows one.
  var GLOBAL_7TV = new Set('reckH PETPET SteerR PepePls peepoSad CrayonTime AlienDance TeaTime gachiGASM FeelsWeirdMan ppL forsenPls RebeccaBlack PianoTime RainTime FeelsStrongMan ApuApustaja FeelsDankMan Gayge GuitarTime PartyParrot WAYTOODANK AYAYA gachiBASS Clap Clap2 nymnCorn RareParrot RoxyPotato peepoHappy BasedGod WineTime peepoPls BillyApprove 7TV nanaAYAYA BibleThump aceStare Stare glorp FeelsOkayMan EZ xdx 7Cinema'.split(' '));
  // A name the chat has shown as an emote, a 7TV global one, or one that looks like one (FeelsWeirdMan, PogChamp).
  function isEmoteName(tok) {
    if (settings.thirdParty === false) return false; // 7TV, BetterTTV and FrankerFaceZ handling is switched off
    return GLOBAL_7TV.has(tok) || knownEmotes().has(tok) || (/^[A-Za-z][A-Za-z0-9]{3,}$/.test(tok) && /[a-z][A-Z]/.test(tok));
  }
  function plainOf(text) {
    return text.split(/\s+/).filter(function (t) { return t && !isEmoteName(t); }).join(' ');
  }
  // Split a piece of text into runs of words and emote names.
  function nameSplit(str) {
    var k = knownEmotes(), out = [], buf = '';
    str.split(/(\s+)/).forEach(function (tok) {
      if (tok && isEmoteName(tok)) { if (buf) out.push({ k: 't', s: buf }); buf = ''; out.push({ k: 'e', name: tok, n: k.get(tok) || null }); }
      else buf += tok;
    });
    if (buf) out.push({ k: 't', s: buf });
    return out;
  }

  var skipWhy = '';
  function writable(ed, text) {
    skipWhy = '';
    if (!settings.enabled || !settings.write || !ed || !text) return false;
    var plain = plainOf(text);
    if (/^[\/!]/.test(text) || !eligible(plain)) return false; // commands and very short messages go as typed
    if (/(^|\s)[@:]\w*$/.test(text)) return false; // an @mention or :emote is still being picked
    if (!editorParts(ed)) return false; // something other than text and emotes (a mention, say): send as typed
    if (window.__cbDetect) {
      var g = window.__cbDetect(plain);
      // Already written in another language than the viewer's own: leave it alone.
      if (g && g.conf >= 0.6 && base(g.lang) !== base(settings.target)) { skipWhy = langName(base(g.lang)); return false; }
    }
    return true;
  }

  async function outTranslate(text, to) {
    var key = base(settings.target) + '>' + to;
    var t = getTranslator(base(settings.target), to);
    if (!t) return null;
    try {
      var out = await t.translate(text);
      return out && out.trim() ? out.trim() : null;
    } catch (err) {
      translators.delete(key);
      return null;
    }
  }

  // The emote or emoji picker counts as open when its search box is really painted on screen right after a click
  // outside the box. Typing in the box clears it, so the preview can never get stuck off.
  var pickerOn = false;
  function pickerShown() {
    var q = document.querySelectorAll('input, [role="searchbox"]');
    for (var i = 0; i < q.length; i++) {
      var lab = (q[i].getAttribute('placeholder') || '') + ' ' + (q[i].getAttribute('aria-label') || '');
      if (!/emote|emoji/i.test(lab)) continue;
      var r = q[i].getBoundingClientRect();
      if (r.width < 40 || r.height < 10 || r.bottom < 0 || r.top > window.innerHeight) continue;
      var top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      if (top && (top === q[i] || q[i].contains(top) || top.contains(q[i]))) {
        for (var n = q[i], o = 1; n && n !== document.body; n = n.parentElement) o *= parseFloat(getComputedStyle(n).opacity);
        if (o > 0.1) return true;
      }
    }
    return false;
  }
  // Something floating over the chat just above the box (7TV's window has no search box we can recognise).
  function floatingOverChat() {
    var ed = editorOf(), r0 = room || (P.room && P.room());
    if (!ed || !r0) return false;
    var r = P.box(ed).getBoundingClientRect();
    var x = r.left + r.width / 2;
    return [r.top - 24, r.top - 140].some(function (y) {
      if (y < 0 || x < 0 || x > window.innerWidth) return false;
      var hit = document.elementsFromPoint(x, y).filter(function (n) { return !n.closest('#cb-wr'); })[0];
      if (!hit || hit === document.body || hit === document.documentElement) return false;
      return !(r0.contains(hit) || hit.contains(r0) || hit.contains(ed) || P.box(ed).contains(hit));
    });
  }
  function pickerOpen() { return pickerOn; }
  document.addEventListener('click', function (e) {
    if (!e.target || !e.target.closest || e.target.closest('#cb-wr')) return;
    // Sites whose emote window can't be spotted: its button toggles it, and typing or clicking the box closes it.
    if (P.pickerBtn && e.target.closest(P.pickerBtn)) { pickerOn = !pickerOn; if (pickerOn) hidePreview(); else queuePreview(150); return; }
    var ed0 = editorOf();
    if (e.target.closest(CHAT_INPUT) || (ed0 && P.box(ed0).contains(e.target) && !e.target.closest('button'))) { pickerOn = false; queuePreview(150); return; }
    if (!editorOf()) return;
    setTimeout(function () { pickerOn = pickerShown() || floatingOverChat(); queuePreview(100); }, 350);
  }, true);
  // Where the emote window is toggled by a button (TikTok), the box takes focus and gets the emote
  // while the window is open, so only a real key press or a click in the box closes it.
  document.addEventListener('focusin', function (e) {
    if (P.pickerBtn) return;
    if (e.target && e.target.closest && e.target.closest(CHAT_INPUT)) { pickerOn = false; queuePreview(150); }
  }, true);
  ['input', 'keydown'].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      if (P.pickerBtn && ev === 'input') return;
      if (e.target && e.target.closest && e.target.closest(CHAT_INPUT)) pickerOn = false;
    }, true);
  });
  var edWatch = null, edWatched = null;
  setInterval(function () {
    var ed = editorOf();
    if (!ed || ed === edWatched) return;
    edWatched = ed;
    if (edWatch) edWatch.disconnect();
    edWatch = new MutationObserver(function () { queuePreview(350); });
    edWatch.observe(ed, { childList: true, subtree: true, characterData: true });
  }, 1500);

  function queuePreview(delay) {
    clearTimeout(wrTimer);
    wrTimer = setTimeout(updatePreview, delay);
  }

  async function updatePreview() {
    if (pickerOpen()) { hidePreview(); return; }
    var ed = editorOf();
    var text = ed ? editorText(ed) : '';
    var to = writeLang();
    if (settings.enabled && settings.write && settings.writeAsk && !to && ed && text && eligible(text) && !/^[\/!]/.test(text)) {
      showHint(settings.writeTo === 'auto'
        ? "ChitChatBot can't tell the chat's language yet. Pick one under \"Write in\" in the menu."
        : 'Chat is already in your language, so nothing to translate.');
      return;
    }
    if (to && ed && text && settings.enabled && settings.write && settings.writeAsk && !editorParts(ed) && unknownItem && !/^[\/!]/.test(text)) {
      showHint('Sent as typed: the box has an item ChitChatBot does not know (' + unknownItem + ').');
      return;
    }
    if (!settings.enabled || !settings.write || !settings.writeAsk || !to || !writable(ed, text)) {
      if (to && settings.enabled && settings.write && settings.writeAsk && skipWhy) showHint('This looks like ' + skipWhy + ' already, so it will be sent as typed.');
      else hidePreview();
      return;
    }
    var sig = partsSig(editorParts(ed) || []);
    if (wr.text === text && wr.sig === sig && wr.to === to && wr.out) { showPreview(); return; }
    var parts = editorParts(ed) || [];
    var hasEmote = parts.some(function (p) { return p.t === 'emote' || nameSplit(p.s).some(function (x) { return x.k === 'e'; }); });
    var out, shown = null;
    if (hasEmote) {
      shown = [];
      var texts = parts.filter(function (p) { return p.t === 'text'; });
      var ok = true;
      var runs = 0;
      parts.forEach(function (p) { if (p.t === 'text') nameSplit(p.s).forEach(function (x) { if (x.k === 't' && /\p{L}/u.test(x.s)) runs++; }); });
      for (var i = 0; i < parts.length && ok; i++) {
        var p = parts[i];
        if (p.t === 'emote') { shown.push(p); continue; }
        var pieces = nameSplit(p.s), made = [], asm = '';
        for (var j = 0; j < pieces.length; j++) {
          var x = pieces[j];
          if (x.k === 'e') { made.push(x); asm += x.name; continue; }
          var lead = (x.s.match(/^\s*/) || [''])[0], trail = (x.s.match(/\s*$/) || [''])[0], core = x.s.trim(), o = core;
          if (core && /\p{L}/u.test(core) && (worthTranslating(core) || runs === 1)) o = await outTranslate(core, to);
          if (core && !o) { ok = false; break; }
          var piece = lead + o + trail;
          made.push({ k: 't', s: piece }); asm += piece;
        }
        if (!ok) break;
        shown.push({ t: 'text', node: p.node, s: p.s, out: asm, pieces: made });
      }
      out = ok ? shown.map(function (p) { return p.t === 'text' ? p.out : ''; }).join(' ').replace(/\s+/g, ' ').trim() : null;
    } else {
      out = await outTranslate(text, to);
    }
    var now = editorOf();
    if (!now || editorText(now) !== text || partsSig(editorParts(now) || []) !== sig) return; // the viewer kept typing; a newer pass is queued
    if (!out) {
      var st = translators.get(base(settings.target) + '>' + to);
      if (!('Translator' in self)) showHint("This page can't use Chrome's built-in translator, so nothing can be translated here.");
      else if (st && st.state === 'no') showHint("Chrome can't translate " + langName(base(settings.target)) + " to " + langName(to) + " on this computer.");
      else if (wrTries > 2) showHint('Getting ' + langName(to) + ' ready. If a bar above the chat box asks, click it to download.');
      else hidePreview();
      if (!(st && st.state === 'no') && wrTries++ < 40) queuePreview(700); // language pack still getting ready
      return;
    }
    if (out.toLowerCase() === text.toLowerCase()) { showHint('The translation is the same as what you typed, so it will be sent as typed.'); return; }
    wrTries = 0;
    wr = { text: text, sig: sig, to: to, out: out, parts: shown };
    showPreview();
  }

  function previewEl() {
    var el = document.getElementById('cb-wr');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'cb-wr';
    el.innerHTML = '<div class="cb-wr-text"></div>' +
      '<div class="cb-wr-actions">' +
      '<button type="button" class="cb-btn" data-a="t"></button>' +
      '<button type="button" class="cb-btn" data-a="o"></button></div>';
    el.addEventListener('mousedown', function (e) { e.preventDefault(); }); // keep the cursor in the chat box
    el.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('button');
      if (!b) return;
      if (b.dataset.a === 't') sendTranslated(); else sendOriginal();
    });
    document.body.appendChild(el);
    return el;
  }

  function placePreview() {
    var el = document.getElementById('cb-wr');
    var ed = editorOf();
    if (!el || !ed) return;
    if (!editorText(ed)) { hidePreview(); return; }
    var box = P.box(ed);
    var r = box.getBoundingClientRect();
    el.style.left = r.left + 'px';
    el.style.width = Math.max(180, r.width) + 'px';
    el.style.bottom = Math.max(8, window.innerHeight - r.top + 6) + 'px';
  }

  function showHint(msg) {
    var el = previewEl();
    el.classList.add('cb-hint');
    el.querySelector('.cb-wr-text').textContent = msg;
    el.style.display = 'block';
    placePreview();
    if (!wrPlaceTimer) wrPlaceTimer = setInterval(placePreview, 500);
  }

  function showPreview() {
    var el = previewEl();
    el.classList.remove('cb-hint');
    var tx = el.querySelector('.cb-wr-text');
    if (wr.parts) {
      tx.textContent = '';
      wr.parts.forEach(function (p) {
        if (p.t === 'emote') tx.appendChild(cloneEmote(p.n));
        else if (p.pieces) p.pieces.forEach(function (x) { tx.appendChild(x.k === 'e' && x.n ? cloneEmote(x.n) : document.createTextNode(x.k === 'e' ? x.name : x.s)); });
        else tx.appendChild(document.createTextNode(p.out));
      });
    } else tx.textContent = wr.out;
    var m = enterMode(), bt = el.querySelector('[data-a="t"]'), bo = el.querySelector('[data-a="o"]');
    bt.textContent = langName(wr.to);
    bo.textContent = 'Original';
    bt.style.order = m === 'tr' ? '2' : '1'; // the button Enter sends is always on the right
    bo.style.order = m === 'own' ? '2' : '1';
    bt.classList.toggle('cb-primary', m === 'tr');
    bo.classList.toggle('cb-primary', m === 'own');
    [[bt, m === 'tr'], [bo, m === 'own']].forEach(function (x) {
      var k = document.createElement('kbd');
      k.textContent = x[1] ? 'Enter' : 'Shift+Enter';
      x[0].appendChild(k);
    });
    el.style.display = 'block';
    placePreview();
    if (!wrPlaceTimer) wrPlaceTimer = setInterval(placePreview, 500);
  }

  function hidePreview() {
    var el = document.getElementById('cb-wr');
    if (el) el.style.display = 'none';
    if (wrPlaceTimer) { clearInterval(wrPlaceTimer); wrPlaceTimer = null; }
  }

  // The chat box updates a moment after an edit, so check the result for a short while.
  async function setEditorText(ed, s) {
    var want = s.replace(/\s+/g, ' ').trim();
    for (var attempt = 0; attempt < 2; attempt++) {
      ed.focus();
      if (attempt === 0) {
        var sel = window.getSelection();
        var r = document.createRange();
        r.selectNodeContents(ed);
        sel.removeAllRanges();
        sel.addRange(r);
      } else {
        document.execCommand('selectAll');
      }
      document.execCommand('insertText', false, s);
      for (var k = 0; k < 8; k++) {
        await new Promise(function (res) { setTimeout(res, 50); });
        if (editorText(ed) === want) return true;
      }
    }
    return false;
  }

  function sendButton(ed) { return P.send(ed); }

  function sendNow(ed) {
    var sent = editorText(ed);
    bypass = true;
    try {
      var btn = sendButton(ed);
      if (btn) btn.click();
      else ed.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    } finally { bypass = false; }
    // If the message is still sitting in the box a moment later, press Enter once.
    setTimeout(function () {
      var e2 = editorOf();
      if (!e2 || editorText(e2) !== sent) return;
      bypass = true;
      try { e2.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); }
      finally { bypass = false; }
    }, 700);
  }

  // Swap each piece of text in the box for its translation, leaving the emotes where they are.
  async function replaceParts(ed) {
    var cur = editorParts(ed);
    if (!cur || partsSig(cur) !== wr.sig) return false;
    var texts = cur.filter(function (p) { return p.t === 'text'; });
    var tr = wr.parts.filter(function (p) { return p.t === 'text'; });
    if (texts.length !== tr.length) return false;
    ed.focus();
    for (var i = texts.length - 1; i >= 0; i--) { // last piece first, so earlier ones stay put
      if (texts[i].s === tr[i].out) continue;
      var r = document.createRange();
      r.selectNodeContents(texts[i].node);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
      document.execCommand('insertText', false, tr[i].out);
      await new Promise(function (res) { setTimeout(res, 60); });
    }
    for (var k = 0; k < 8; k++) {
      var now = editorParts(ed);
      if (now && now.filter(function (p) { return p.t === 'text'; }).map(function (p) { return p.s; }).join(' ').replace(/\s+/g, ' ').trim() === wr.out) return true;
      await new Promise(function (res) { setTimeout(res, 50); });
    }
    return false;
  }

  async function sendTranslated() {
    var ed = editorOf();
    if (!ed) return;
    var text = editorText(ed), to = writeLang();
    if (wr.parts && wr.text === text && wr.to === to && wr.out) {
      var done = await replaceParts(ed);
      if (!done) { skipUntil = Date.now() + 8000; hidePreview(); return; }
      hidePreview();
      wr = { text: '', to: '', out: null };
      sendNow(editorOf() || ed);
      return;
    }
    var out = (wr.text === text && !wr.parts && wr.to === to && wr.out) || (to ? await outTranslate(text, to) : null);
    ed = editorOf();
    if (!ed || editorText(ed) !== text) return;
    if (!out || !(await setEditorText(ed, out))) {
      // Could not translate or swap the text: leave the box alone and let the next Enter send it as typed.
      skipUntil = Date.now() + 8000;
      hidePreview();
      return;
    }
    hidePreview();
    wr = { text: '', to: '', out: null };
    sendNow(ed);
  }

  function sendOriginal() {
    var ed = editorOf();
    if (!ed) return;
    hidePreview();
    sendNow(ed);
  }

  // Decide, right when Enter or the Chat button is pressed, whether to translate first.
  function shouldTranslate(ed) {
    if (bypass || !settings.enabled || !settings.write || !ed || Date.now() < skipUntil) return false;
    var text = editorText(ed), to = writeLang();
    if (!to || !writable(ed, text)) return false;
    if (wr.text === text && wr.to === to && wr.out && wr.sig === partsSig(editorParts(ed) || [])) return true;
    var st = translators.get(base(settings.target) + '>' + to);
    return !!(st && st.state === 'ready');
  }

  // What Enter does while a translation is pending: 'tr' sends it, 'own' sends what was typed, 'none' does nothing.
  function enterMode() {
    return settings.enterOwn ? 'own' : 'tr';
  }

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' || e.ctrlKey || e.altKey || e.metaKey || e.isComposing) return;
    var ed = e.target && e.target.closest ? e.target.closest(CHAT_INPUT) : null;
    if (!ed || !shouldTranslate(ed)) return;
    // Enter does what the menu says; Shift+Enter does the other one.
    var m = enterMode(), what = e.shiftKey ? (m === 'tr' ? 'own' : 'tr') : m;
    if (e.shiftKey && m === 'none') what = 'own';
    e.preventDefault();
    e.stopImmediatePropagation();
    if (what === 'tr') sendTranslated();
    else if (what === 'own') sendOriginal();
  }, true);

  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('button') : null;
    if (!b || bypass || b.closest('#cb-wr')) return;
    var ed = editorOf();
    if (!ed || sendButton(ed) !== b || !shouldTranslate(ed)) return;
    var m = enterMode();
    if (m === 'own') { hidePreview(); return; }
    e.preventDefault();
    e.stopImmediatePropagation();
    if (m === 'tr') sendTranslated();
  }, true);

  // Some editors (YouTube's) are easiest to follow by also listening to key presses and pastes.
  ['keyup', 'paste', 'cut'].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      if (!e.target || !e.target.closest || !e.target.closest(CHAT_INPUT)) return;
      queuePreview(250);
    }, true);
  });

  document.addEventListener('input', function (e) {
    if (!e.target || !e.target.closest || !e.target.closest(CHAT_INPUT)) return;
    wrTries = 0;
    queuePreview(250);
  }, true);

  // Match the chat's own text size and font, so translations (and the write preview) look native.
  var lastFs = '';
  function syncSize() {
    // Use a message that is really on screen with a normal text size, so a hidden or
    // zero-size element can never shrink our lines to nothing.
    var node = null, items = P.items(room);
    for (var i = items.length - 1; i >= 0 && !node && i >= items.length - 25; i--) {
      var t = P.textNodes(items[i]);
      for (var j = 0; j < t.length && !node; j++) {
        if (!t[j].textContent.trim()) continue;
        var px = parseFloat(getComputedStyle(t[j]).fontSize);
        var box = t[j].getBoundingClientRect();
        if (px >= 9 && px <= 40 && box.height > 0 && box.width > 0) node = t[j];
      }
    }
    if (!node) return;
    var cs = getComputedStyle(node);
    // The chat's background: the nearest parent that is not transparent.
    var bg = '', fg = cs.color, el = node;
    while (el && el.nodeType === 1) {
      var c = getComputedStyle(el).backgroundColor;
      if (c && c !== 'transparent' && !/rgba\(.*, ?0\)$/.test(c)) { bg = c; break; }
      el = el.parentElement;
    }
    var sig = cs.fontSize + '|' + cs.fontFamily + '|' + bg + '|' + fg;
    if (sig === lastFs) return;
    lastFs = sig;
    var root = document.documentElement.style;
    root.setProperty('--cb-fs', cs.fontSize);
    root.setProperty('--cb-ff', cs.fontFamily);
    if (bg) { root.setProperty('--cb-bg', bg); root.setProperty('--cb-fg', fg); }
  }

  function scan() {
    scheduled = false;
    if (!room || !room.isConnected) return;
    syncSize();
    P.items(room).forEach(function (item) {
      handle(item);
      handleReply(item);
    });
  }

  // ---- watching the chat ----
  var observer = new MutationObserver(schedule);

  // Kick scrolls to the bottom when a message arrives. Our translation line is added a moment later
  // and would sit just below the visible area, so scroll down again, but only if the viewer
  // was already at the bottom (scroll events come from the viewer or Kick, not from our edits).
  var stick = true;
  var scroller = null;
  function onScroll() {
    if (scroller) stick = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 40;
  }
  function keepBottom() {
    if (!stick || !room || !scroller) return;
    var go = function () { if (stick && room && room.isConnected && scroller) scroller.scrollTop = scroller.scrollHeight; };
    requestAnimationFrame(go);
    setTimeout(go, 150);
  }

  // These sites are single-page apps, so the chat element is replaced when you change channel.
  setInterval(function () {
    var r = P.room();
    if (r === room) return;
    observer.disconnect();
    room = r;
    if (room) {
      scroller = P.scroller(room);
      observer.observe(room, { childList: true, subtree: true, characterData: true });
      scroller.addEventListener('scroll', onScroll, { passive: true });
      stick = true;
      schedule();
    }
  }, 1000);

  // ---- settings ----
  function applySettings() {
    // A fresh start for the new language: forget old failures and stale download prompts.
    failed.clear();
    pairFails.clear();
    translators.forEach(function (e, k) { if (!e.t) translators.delete(k); });
    pending.forEach(function (p, k) { if (k !== 'detector' && k.split('>')[0] !== base(settings.target) && k.split('>')[1] !== base(settings.target)) pending.delete(k); });
    renderPill();
    if (settings.showTag === false) document.documentElement.dataset.cbNoTag = '1';
    else delete document.documentElement.dataset.cbNoTag;
    if (settings.showOriginal) delete document.documentElement.dataset.cbHideOrig;
    else document.documentElement.dataset.cbHideOrig = '1';
    document.querySelectorAll('.cb-tr, .cb-rtr').forEach(function (n) { n.remove(); });
    wr = { text: '', to: '', out: null };
    hidePreview();
    wrTries = 0;
    queuePreview(300);
    schedule();
  }

  chrome.storage.sync.get(DEFAULTS, function (s) {
    settings = Object.assign({}, DEFAULTS, s);
    applySettings();
    getDetector(); // start checking what the browser supports right away
  });

  chrome.storage.onChanged.addListener(function (changes) {
    Object.keys(changes).forEach(function (k) { settings[k] = changes[k].newValue; });
    if (changes.target) {
      // A new language: start clean so nothing from the old one is reused.
      cache.clear(); inflight.clear(); translators.clear(); langLog.length = 0;
    }
    applySettings();
  });
})();
