// Small language guesser, used only when the browser's own detector is unavailable (for example in Brave).
// It looks at the writing system first, then at common words for Latin-script languages.
// It also remembers which language the chat mostly uses, to help with very short messages.
(function () {
  'use strict';

  function strip(s) { return s.normalize('NFD').replace(/[̀-ͯ]/g, ''); }

  var WORDS = {
    en: 'the and is are you that this with for was have not but what just like they can its your all how when so my me good nice lol omg hello hi thanks insane clip last from about really very much where here there been will would should got get one more of to it he she we be do did am im dont cant yeah yes nah bro dude gg wtf pls please play played watch watching stream chat game time first tomorrow lets ez pog poggers lmao wow crazy'.split(' '),
    es: 'el los las una es por con para pero muy más esto qué está jaja hola gracias bien del como cómo estoy tengo vamos buena jugada puedo creer eso porque también todos todo ahora cuando donde quien sus mis tus dónde estan están estas eres soy somos cuidando mañana primera vez ver jugar persona dale vamo weon wey buenas noches dias quiero amo viva gol golazo mejor siempre nunca nada algo hay han fue será ser son tiene tienen hacer dios mierda carajo puta joder tio hermano amigo y le lo un no ya se te mi tu su de la que en me al les mismo papi usted regala regale celular severo estudio mero foco locos tan tanto hace hacer dice digo mira oye'.split(' '),
    pt: 'não nao você voce uma são está pra né obrigado obrigada olá ola aqui vez primeira mais muito também com para em dos das isso esse essa saudações brasil bom boa vocês tudo ainda quando onde kkk kkkk kkkkk vc blz valeu galera'.split(' '),
    fr: 'le les des du et est une que qui pas pour dans je tu il elle nous vous sur avec très bien mais oui non merci salut bonjour comment quoi aussi tout cette ça suis sont mdr ptdr'.split(' '),
    de: 'der die das und ist nicht ich du er sie wir ein eine mit auf für wie was wann noch heute auch dann aber ja nein danke hallo lange streamst bist habe sind wird kannst schon'.split(' '),
    it: 'il lo gli che è un una per con non sono mi ti ci come più molto anche ciao grazie tuo tua tantissimo migliorato questo quando dove perché cosa bene'.split(' '),
    id: 'yang dan di ini itu tidak ga gak nggak aku kamu saya dengan untuk dari ke apa bang mantap lanjut terus banget udah sudah aja nih dong kok wkwk gimana kapan bisa ada lagi sama juga atau berapa lama hari'.split(' '),
    tr: 'bir ve bu çok için ama ne ben sen var yok evet hayır merhaba selam nasıl güzel ile mi mı bugün şimdi harika'.split(' '),
    nl: 'de het een en van is dat niet ik je jij we met op voor maar ook wat hoe hallo bedankt goed heel nog wel'.split(' '),
    pl: 'nie to jest się na że jak co ale tak dla czy cześć dzięki bardzo dzisiaj teraz'.split(' ')
  };
  var SETS = {};
  Object.keys(WORDS).forEach(function (l) {
    SETS[l] = {};
    WORDS[l].forEach(function (w) { SETS[l][strip(w)] = true; });
  });

  var HINTS = [
    [/[ãõ]/g, 'pt', 2], [/[ñ¿¡]/g, 'es', 2], [/ß/g, 'de', 2], [/[äöü]/g, 'de', 1],
    [/[ığş]/g, 'tr', 2], [/[łąęśźżćń]/g, 'pl', 2], [/[èùâêîôûœ]/g, 'fr', 1], [/ç/g, 'pt', 1]
  ];

  // Which languages the last few clear messages were in.
  var history = [];
  function note(lang) {
    history.push(lang);
    if (history.length > 40) history.shift();
  }
  function dominant() {
    if (history.length < 6) return null;
    var counts = {};
    history.forEach(function (l) { counts[l] = (counts[l] || 0) + 1; });
    var best = Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a]; })[0];
    return counts[best] / history.length >= 0.6 ? best : null;
  }

  // quiet: used on what the viewer is typing. It ignores what the chat mostly speaks and leaves the chat's language memory alone.
  function latin(text, quiet) {
    var lower = text.toLowerCase();
    var tokens = strip(lower).match(/[\p{L}']+/gu) || [];
    if (tokens.length < 1) return null;
    var score = {};
    Object.keys(SETS).forEach(function (l) { score[l] = 0; });
    tokens.forEach(function (t) {
      Object.keys(SETS).forEach(function (l) { if (SETS[l][t]) score[l]++; });
    });
    HINTS.forEach(function (h) {
      var m = lower.match(h[0]);
      if (m) score[h[1]] += h[2] * Math.min(m.length, 2);
    });
    var ranked = Object.keys(score).sort(function (a, b) { return score[b] - score[a]; });
    var best = ranked[0], second = ranked[1];
    var pd = quiet ? null : dominant();
    if (pd) {
      // The chat mostly uses one language. Another language has to win clearly to override it,
      // because common words are shared between languages (for example "un" and "lo").
      if (best !== pd && score[best] >= 2 && score[best] >= score[pd] + 2) {
        note(best);
        return { lang: best, conf: 0.7 };
      }
      // With no recognizable word at all, only guess for messages of three or more words.
      if (score[pd] + 1 >= score[best] && (score[pd] >= 1 || tokens.length >= 3)) {
        if (score[pd] >= 2) note(pd);
        return { lang: pd, conf: 0.65 };
      }
      return null;
    }
    if (score[best] >= 2 && score[best] >= score[second] + 1) {
      if (!quiet) note(best);
      return { lang: best, conf: 0.7 };
    }
    return null;
  }

  // Hindi written in English letters ("Hinglish"). Browsers' detectors call it English,
  // so spot it by common Hindi words that are not English words.
  var HINGLISH = {};
  ('bhai hai hain nhi nhii nahi nahin kya kuch bhi abhi aap tum tumhe tumhara mera meri tera teri mujhe hum humko ' +
   'yaar accha acha achha kaise kaisa kyun kyu matlab bahut bohot bhot sab kar karo karna raha rahi rahe ke ko ka ki ' +
   'ye yeh wo woh aur lekin par mein se tha thi the ho hoga hogi gaya gayi sakte sakta chahiye mat wala wali sahi ' +
   'jaldi pata dono khush aaya aayi diya liya kab kahan kaun kitna kitne bilkul bas toh').split(' ').forEach(function (w) { HINGLISH[w] = true; });
  window.__cbHinglish = function (text) {
    var t = String(text || '').replace(/https?:\/\/\S+/g, ' ').toLowerCase();
    var tokens = t.match(/[a-z]+/g) || [];
    if (tokens.length < 3) return false;
    var hits = 0;
    tokens.forEach(function (w) { if (HINGLISH[w]) hits++; });
    return hits >= 2 && hits / tokens.length >= 0.3;
  };

  window.__cbDetect = function (text, quiet) {
    var t = String(text || '').replace(/https?:\/\/\S+/g, ' ');
    var r = null;
    if (/[぀-ヿ]/.test(t)) r = { lang: 'ja', conf: 1 };
    else if (/[가-힯]/.test(t)) r = { lang: 'ko', conf: 1 };
    else if (/[一-鿿]/.test(t)) r = { lang: 'zh', conf: 0.9 };
    else if (/[Ѐ-ӿ]/.test(t)) r = { lang: /[іїєґ]/i.test(t) ? 'uk' : 'ru', conf: 0.9 };
    else if (/[؀-ۿ]/.test(t)) r = /[پچژگ]/.test(t) ? null : { lang: 'ar', conf: 0.9 };
    else if (/[฀-๿]/.test(t)) r = { lang: 'th', conf: 1 };
    else if (/[ऀ-ॿ]/.test(t)) r = { lang: 'hi', conf: 0.9 };
    else return latin(t, quiet);
    if (r && !quiet) note(r.lang);
    return r;
  };
})();
