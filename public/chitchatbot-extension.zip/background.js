// Greys the toolbar icon while ChitChatBot is switched off, and brings the colour back when it is on.
function paintIcon(on) {
  var s = on ? '' : '-off';
  chrome.action.setIcon({ path: { 16: 'icon16' + s + '.png', 48: 'icon48' + s + '.png', 128: 'icon128' + s + '.png' } });
}
function sync() {
  chrome.storage.sync.get({ enabled: true }, function (s) { paintIcon(s.enabled !== false); });
}
chrome.runtime.onInstalled.addListener(sync);
chrome.runtime.onStartup.addListener(sync);
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area === 'sync' && changes.enabled) paintIcon(changes.enabled.newValue !== false);
});
sync();
