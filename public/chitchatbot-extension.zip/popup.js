(function () {
  // Tint the menu to match the site in the active tab (Kick green, Twitch purple, YouTube red). Anywhere else it keeps its own blush pink.
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var u = tabs && tabs[0] && tabs[0].url || '';
      var h = '';
      try { h = new URL(u).hostname; } catch (e) {}
      var site = /twitch\.tv$/.test(h) ? 'twitch' : /youtube\.com$/.test(h) ? 'youtube' : /tiktok\.com$/.test(h) ? 'tiktok' : /kick\.com$/.test(h) ? 'kick' : '';
      if (site) document.documentElement.dataset.site = site;
    });
  } catch (e) {}
  'use strict';
  var LANGS = [
    ['en', 'English'], ['es', 'Español'], ['pt', 'Português'], ['fr', 'Français'],
    ['de', 'Deutsch'], ['it', 'Italiano'], ['nl', 'Nederlands'], ['pl', 'Polski'],
    ['tr', 'Türkçe'], ['ru', 'Русский'], ['uk', 'Українська'], ['ar', 'العربية'],
    ['hi', 'हिन्दी'], ['id', 'Bahasa Indonesia'], ['vi', 'Tiếng Việt'], ['th', 'ไทย'],
    ['ja', '日本語'], ['ko', '한국어'], ['zh', '中文']
  ];
  var guess = (navigator.language || 'en').split('-')[0].toLowerCase();
  var DEFAULTS = {
    enabled: true,
    target: LANGS.some(function (l) { return l[0] === guess; }) ? guess : 'en',
    showOriginal: true,
    showEmotes: true,
    showReplies: true,
    write: true,
    showTag: false,
    writeTo: 'auto',
    writeFrom: 'auto',
    writeAsk: true,
    enterTr: true,
    enterOwn: false,
    autoPack: true,
    thirdParty: true,
    uiLang: 'auto',
    skip: []
  };

  function $(id) { return document.getElementById(id); }
  var power = $('power'), target = $('target'), both = $('both'), only = $('only');
  var emotes = $('emotes'), replies = $('replies'), tag = $('tag');
  var write = $('write'), writeTo = $('writeTo'), writeFrom = $('writeFrom'), writeAsk = $('writeAsk');
  var readCard = $('readCard'), writeCard = $('writeCard'), stat = $('stat');

  function fill(select, withAuto) {
    if (withAuto) {
      var a = document.createElement('option');
      a.value = 'auto';
      a.textContent = CBI.t('auto'); a.setAttribute('data-auto', '1');
      select.appendChild(a);
    }
    LANGS.forEach(function (l) {
      var o = document.createElement('option');
      o.value = l[0];
      o.textContent = l[1];
      select.appendChild(o);
    });
  }
  fill(target, false);
  fill(writeTo, true);
  fill(writeFrom, true);
  var af = writeFrom.querySelector('[data-auto]'); af.setAttribute('data-autotype', '1'); af.removeAttribute('data-auto');
  var uiLang = $('uiLang');
  [['auto', ''], ['en', 'English'], ['es', 'Español'], ['pt', 'Português'], ['fr', 'Français'], ['ja', '日本語'], ['ko', '한국어']].forEach(function (l) {
    var o = document.createElement('option'); o.value = l[0]; o.textContent = l[1]; uiLang.appendChild(o);
  });
  function applyLang(pref) {
    CBI.set(pref);
    uiLang.options[0].textContent = CBI.t('menuAuto');
    var a = writeTo.querySelector('[data-auto]'); if (a) a.textContent = CBI.t('auto');
    var f = writeFrom.querySelector('[data-autotype]'); if (f) f.textContent = CBI.t('autoType');
  }

  if (!('Translator' in self)) $('warn').hidden = false;
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;

  function sw(el, on) { el.setAttribute('aria-checked', String(on)); }

  function paint(s) {
    sw(power, s.enabled);
    sw(emotes, s.showEmotes);
    sw(replies, s.showReplies);
    sw(tag, s.showTag);
    sw($('autoPack'), s.autoPack);
    sw(write, s.write);
    sw(writeAsk, s.writeAsk);
    var trLabel = CBI.t('trans') + (s.writeTo && s.writeTo !== 'auto' ? ' (' + ([].slice.call(writeTo.options).filter(function (o) { return o.value === s.writeTo; })[0] || {}).textContent + ')' : '');
    $('swapKeys').title = CBI.t('swap');
    $('kEnter').textContent = s.enterOwn ? CBI.t('typed') : trLabel;
    $('kShift').textContent = s.enterOwn ? trLabel : CBI.t('typed');
    sw($('thirdParty'), s.thirdParty);
    target.value = s.target;
    writeTo.value = s.writeTo;
    writeFrom.value = s.writeFrom || 'auto';
    both.setAttribute('aria-pressed', String(s.showOriginal));
    only.setAttribute('aria-pressed', String(!s.showOriginal));
    stat.textContent = CBI.t(s.enabled ? 'on' : 'off');
    readCard.classList.toggle('dim', !s.enabled);
    writeCard.classList.toggle('dim', !s.enabled);
    $('emoCard').classList.toggle('dim', !s.enabled);
    writeCard.classList.toggle('off', !s.write);
    paintSkip(s);
  }

  // ---- skip list: names whose messages never get a translation (kept on this browser) ----
  var SKIP_MAX = 50;
  var skipKey = function (n) { return String(n).toLowerCase().replace(/^@+/, '').replace(/[-_\s]/g, ''); };
  function paintSkip(s) {
    var list = Array.isArray(s.skip) ? s.skip : [];
    var box = $('skipChips');
    box.textContent = '';
    if (!list.length) {
      var e = document.createElement('span'); e.className = 'empty'; e.textContent = CBI.t('skipEmpty'); box.appendChild(e);
    }
    list.forEach(function (n) {
      var c = document.createElement('span'); c.className = 'chip';
      var t = document.createElement('span'); t.textContent = n; t.title = n; c.appendChild(t);
      var b = document.createElement('button'); b.type = 'button'; b.textContent = '\u00d7'; b.setAttribute('aria-label', 'Remove ' + n);
      b.addEventListener('click', function () { skipSet(s, list.filter(function (x) { return x !== n; })); });
      c.appendChild(b); box.appendChild(c);
    });
    $('skipCount').textContent = list.length ? list.length + ' ' + CBI.t('skipN') : '';
    $('skipCard').classList.toggle('dim', !s.enabled);
  }
  function skipSet(s, list) {
    s.skip = list;
    chrome.storage.sync.set({ skip: list });
    paintSkip(s);
  }

  // bottom tabs
  var tabBtns = document.querySelectorAll('.tabs button');
  function showTab(t) {
    tabBtns.forEach(function (b) { b.setAttribute('aria-selected', String(b.dataset.t === t)); });
    ['read', 'write', 'emo', 'set', 'sup'].forEach(function (k) { $('tab-' + k).hidden = k !== t; });
    try { localStorage.setItem('cbTab', t); } catch (e) {}
  }
  tabBtns.forEach(function (b) { b.addEventListener('click', function () { showTab(b.dataset.t); }); });
  try { var saved = localStorage.getItem('cbTab'); if (saved === 'read' || saved === 'write' || saved === 'emo' || saved === 'set' || saved === 'sup') showTab(saved); } catch (e) {}

  chrome.storage.sync.get(DEFAULTS, function (s) {
    var cur = Object.assign({}, DEFAULTS, s);
    applyLang(cur.uiLang);
    uiLang.value = cur.uiLang;
    paint(cur);

    uiLang.addEventListener('change', function () {
      cur.uiLang = uiLang.value;
      chrome.storage.sync.set({ uiLang: cur.uiLang });
      applyLang(cur.uiLang);
      paint(cur);
    });

    function flip(el, key) {
      el.addEventListener('click', function () {
        cur[key] = !cur[key];
        var o = {}; o[key] = cur[key];
        chrome.storage.sync.set(o);
        paint(cur);
      });
    }
    flip(power, 'enabled');
    flip(emotes, 'showEmotes');
    flip(replies, 'showReplies');
    flip(tag, 'showTag');
    flip($('autoPack'), 'autoPack');
    flip(write, 'write');
    flip(writeAsk, 'writeAsk');
    flip($('thirdParty'), 'thirdParty');

    $('skipForm').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var v = $('skipName').value.trim().replace(/^@+/, '');
      var note = $('skipNote');
      if (!/^[\w-]{1,40}$/.test(v)) return;
      var list = Array.isArray(cur.skip) ? cur.skip : [];
      if (list.some(function (x) { return skipKey(x) === skipKey(v); })) { note.textContent = v + ' ' + CBI.t('skipDup'); return; }
      if (list.length >= SKIP_MAX) { note.textContent = SKIP_MAX + ' max. Someone has to go.'; return; }
      note.textContent = '';
      $('skipName').value = '';
      skipSet(cur, [v].concat(list));
    });

    $('swapKeys').addEventListener('click', function () { cur.enterOwn = !cur.enterOwn; cur.enterTr = !cur.enterOwn; chrome.storage.sync.set({ enterOwn: cur.enterOwn, enterTr: cur.enterTr }); paint(cur); });

    function setOrig(v) {
      cur.showOriginal = v;
      chrome.storage.sync.set({ showOriginal: v });
      paint(cur);
    }
    both.addEventListener('click', function () { setOrig(true); });
    only.addEventListener('click', function () { setOrig(false); });

    target.addEventListener('change', function () {
      cur.target = target.value;
      chrome.storage.sync.set({ target: cur.target });
      paint(cur);
    });
    writeFrom.addEventListener('change', function () {
      cur.writeFrom = writeFrom.value;
      chrome.storage.sync.set({ writeFrom: cur.writeFrom });
      paint(cur);
    });
    writeTo.addEventListener('change', function () {
      cur.writeTo = writeTo.value;
      chrome.storage.sync.set({ writeTo: cur.writeTo });
      paint(cur);
    });
  });
})();
