(function () {
  // Tint the menu to match the site in the active tab (Kick green, Twitch purple, YouTube red). Anywhere else it keeps its own blush pink.
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var u = tabs && tabs[0] && tabs[0].url || '';
      var h = '';
      try { h = new URL(u).hostname; } catch (e) {}
      var site = /twitch\.tv$/.test(h) ? 'twitch' : /youtube\.com$/.test(h) ? 'youtube' : /tiktok\.com$/.test(h) ? 'tiktok' : /kick\.com$/.test(h) ? 'kick' : '';
      if (site) document.documentElement.dataset.site = site;
    });
  } catch (e) {}
  'use strict';
  var LANGS = [
    ['en', 'English'], ['es', 'Español'], ['pt', 'Português'], ['fr', 'Français'],
    ['de', 'Deutsch'], ['it', 'Italiano'], ['nl', 'Nederlands'], ['pl', 'Polski'],
    ['tr', 'Türkçe'], ['ru', 'Русский'], ['uk', 'Українська'], ['ar', 'العربية'],
    ['hi', 'हिन्दी'], ['id', 'Bahasa Indonesia'], ['vi', 'Tiếng Việt'], ['th', 'ไทย'],
    ['ja', '日本語'], ['ko', '한국어'], ['zh', '中文']
  ];
  var guess = (navigator.language || 'en').split('-')[0].toLowerCase();
  var DEFAULTS = {
    enabled: true,
    target: LANGS.some(function (l) { return l[0] === guess; }) ? guess : 'en',
    showOriginal: true,
    showEmotes: true,
    showReplies: true,
    write: true,
    showTag: false,
    writeTo: 'auto',
    writeAsk: true,
    enterTr: true,
    enterOwn: false,
    thirdParty: true
  };

  function $(id) { return document.getElementById(id); }
  var power = $('power'), target = $('target'), both = $('both'), only = $('only');
  var emotes = $('emotes'), replies = $('replies'), tag = $('tag');
  var write = $('write'), writeTo = $('writeTo'), writeAsk = $('writeAsk');
  var readCard = $('readCard'), writeCard = $('writeCard'), stat = $('stat');

  function fill(select, withAuto) {
    if (withAuto) {
      var a = document.createElement('option');
      a.value = 'auto';
      a.textContent = 'Auto (chat language)';
      select.appendChild(a);
    }
    LANGS.forEach(function (l) {
      var o = document.createElement('option');
      o.value = l[0];
      o.textContent = l[1];
      select.appendChild(o);
    });
  }
  fill(target, false);
  fill(writeTo, true);

  if (!('Translator' in self)) $('warn').hidden = false;
  $('ver').textContent = 'v' + chrome.runtime.getManifest().version;

  function sw(el, on) { el.setAttribute('aria-checked', String(on)); }

  function paint(s) {
    sw(power, s.enabled);
    sw(emotes, s.showEmotes);
    sw(replies, s.showReplies);
    sw(tag, s.showTag);
    sw(write, s.write);
    sw(writeAsk, s.writeAsk);
    $('enterTr').setAttribute('aria-pressed', String(!s.enterOwn));
    $('enterOwn').setAttribute('aria-pressed', String(!!s.enterOwn));
    sw($('thirdParty'), s.thirdParty);
    target.value = s.target;
    writeTo.value = s.writeTo;
    both.setAttribute('aria-pressed', String(s.showOriginal));
    only.setAttribute('aria-pressed', String(!s.showOriginal));
    stat.textContent = s.enabled ? 'Translating chat for you' : 'Paused';
    readCard.classList.toggle('dim', !s.enabled);
    writeCard.classList.toggle('dim', !s.enabled);
    $('emoCard').classList.toggle('dim', !s.enabled);
    writeCard.classList.toggle('off', !s.write);
  }

  // bottom tabs
  var tabBtns = document.querySelectorAll('.tabs button');
  function showTab(t) {
    tabBtns.forEach(function (b) { b.setAttribute('aria-selected', String(b.dataset.t === t)); });
    ['read', 'write', 'emo', 'sup'].forEach(function (k) { $('tab-' + k).hidden = k !== t; });
    try { localStorage.setItem('cbTab', t); } catch (e) {}
  }
  tabBtns.forEach(function (b) { b.addEventListener('click', function () { showTab(b.dataset.t); }); });
  try { var saved = localStorage.getItem('cbTab'); if (saved === 'read' || saved === 'write' || saved === 'emo' || saved === 'sup') showTab(saved); } catch (e) {}

  chrome.storage.sync.get(DEFAULTS, function (s) {
    var cur = Object.assign({}, DEFAULTS, s);
    paint(cur);

    function flip(el, key) {
      el.addEventListener('click', function () {
        cur[key] = !cur[key];
        var o = {}; o[key] = cur[key];
        chrome.storage.sync.set(o);
        paint(cur);
      });
    }
    flip(power, 'enabled');
    flip(emotes, 'showEmotes');
    flip(replies, 'showReplies');
    flip(tag, 'showTag');
    flip(write, 'write');
    flip(writeAsk, 'writeAsk');
    flip($('thirdParty'), 'thirdParty');

    $('enterTr').addEventListener('click', function () { cur.enterOwn = false; cur.enterTr = true; chrome.storage.sync.set({ enterOwn: false, enterTr: true }); paint(cur); });
    $('enterOwn').addEventListener('click', function () { cur.enterOwn = true; cur.enterTr = false; chrome.storage.sync.set({ enterOwn: true, enterTr: false }); paint(cur); });

    function setOrig(v) {
      cur.showOriginal = v;
      chrome.storage.sync.set({ showOriginal: v });
      paint(cur);
    }
    both.addEventListener('click', function () { setOrig(true); });
    only.addEventListener('click', function () { setOrig(false); });

    target.addEventListener('change', function () {
      cur.target = target.value;
      chrome.storage.sync.set({ target: cur.target });
      paint(cur);
    });
    writeTo.addEventListener('change', function () {
      cur.writeTo = writeTo.value;
      chrome.storage.sync.set({ writeTo: cur.writeTo });
      paint(cur);
    });
  });
})();
